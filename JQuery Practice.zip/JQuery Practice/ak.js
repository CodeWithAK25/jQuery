
      $(document).ready(function(){

        $('.h-btn').click(function(){
            $('.f-box').hide(3000);
            $('.s-btn').click(function(){
                $('.f-box').show(3000);
                })
        
        });
        $('.t-btn').click(function(){
            $('.t-box').toggle(3000);
            
        
        });
        $('.s-t-btn').click(function(){
            $('.s-t-box').slideToggle(3000);
            
        
        });
        $('.f-t-btn').click(function(){
            $('.f-t-box').fadeToggle(3000)
        });
        $('.f-i-btn').click(function(){
            $('.f-i-box').fadeIn(3000)
        });
        $('.f-o-btn').click(function(){
            $('.f-o-box').fadeOut(3000)
        });
        $('.f-to-btn').click(function(){
            $('.f-to-box').fadeTo('slow',.2)
        });
        $('.m-e-btn').mouseenter(function(){
            $('.m-e-box').slideToggle(3000)
        });
        $('.m-l-btn').mouseenter(function(){
            $('.m-l-box').toggle(3000)
        });
        $('.m-d-btn').mousedown(function(){
            $('.m-d-box').fadeToggle(3000)
        });
        $('.m-u-btn').mouseup(function(){
            $('.m-u-box').slideToggle(3000)
        });
        $(".m-h-btn").hover(function(){
            alert("You entered Hover Button!");
          },
          function(){
            alert("Bye! You now leave Hover Button!");
          });
          $(".i-f").focus(function(){
            $(this).css("background-color", "#cccccc");
          });

          $(".f-i").focus(function(){
            $(this).css("background-color", "yellow");
          });
          $(".f-i").blur(function(){
            $(this).css("background-color", "green");
          });

          $("p").on("click", function(){
            $(this).hide();
          });
          $(".to-top a").click(function(){
            $('html,body').animate({'scrollTop': 0},2000);

            return false;
          });

          $(window).scroll(function(){
            if ($(window).scrollTop() > 600){
              $('.to-top ').show();
            }
            else{
              $ ('.to-top ').hide()
            }
          });

          $('.a-btn').click(function(){
            $('.a-box').animate({'left':'400px'},2000);
                       
          });
          $('.a-btn').mouseenter(function(){
            $('.a-box').animate({'top':'400px'},2000);
                       
          });
          $('.a-btn').mouseleave(function(){
            $('.a-box').animate({'top':'-0px'},2000);
                       
          });
        
        
      });